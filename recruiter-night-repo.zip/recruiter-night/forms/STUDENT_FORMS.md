# STUDENT INTAKE FORMS
### SigEp Mo Gamma — Recruiter Night · Missouri S&T

There are **two** student forms. This is deliberate, and it solves the wildcard timing problem.

---

# 🎯 THE WILDCARD PROBLEM — AND THE FIX

**The problem you identified:** students need to register early (to drive turnout and let you
cap attendance), but the recruiter roster isn't locked until ~Sept 1. You can't ask a student
on August 5 to "pick two companies" from a list that doesn't exist yet.

**The fix: three layers, in priority order.** Every student gets wildcards no matter what,
and nobody's picks depend on a list existing yet.

### Layer 1 — Dream List *(Stage 1, free text)*
Students name up to 3 companies they'd love to meet — **any company, invited or not.**
If that firm later commits, the converter fuzzy-matches the name and the wildcard applies
automatically.

> 💡 **This layer has a second job that's arguably more valuable than matching.**
> It hands you a ranked list of exactly which companies your students want in the room —
> which becomes your recruiter outreach target list. You stop guessing who to email.
> Run the converter's `--dreamlist` report in mid-August and chase the top names.

### Layer 2 — Preference Profile *(Stage 1, structured)*
Industry ranking, company size, and location preference. These describe *what kind of
company* a student wants without naming one. If a student never picks a real company,
the converter synthesizes **proxy wildcards** — the confirmed firms that best fit their
stated preferences. No student is ever penalized for the roster not existing yet.

### Layer 3 — Confirmation Round *(Stage 2, 30 seconds)*
Once the roster is locked (Sept 1), you send a very short second form with the real
company list as checkboxes. Whoever responds gets exact wildcards. Whoever doesn't
falls back to Layer 2 automatically.

**Priority when the converter runs:** Stage 2 pick → Layer 1 name match → Layer 2 proxy.

---
---

# FORM 1 — REGISTRATION *(open it now, close Sept 8)*

> **Form title:** Recruiter Night — Student Registration
> **Form description:**
> Tuesday, September 15 · 5:30–8:00 PM · Free dinner (Pancheros) · Business casual
>
> Meet recruiters one week before the career fair — including companies that
> **aren't attending the fair at all.** You'll get a personalized card listing the
> companies matched to your major, year, and interests. No standing in line, no
> wandering. Dinner first, everyone eats together, then you meet your matches.
>
> Space is limited and we expect to fill up. Registering does not guarantee a spot —
> we'll confirm by email. Takes about 3 minutes.

---

## SECTION 1 — About You

**Q1. Full name** `[Text — required]`

**Q2. Missouri S&T email** `[Text — required, email format]`

**Q3. Major** `[Choice — required, dropdown]`
*Helper text:* If you're double-majoring, pick the one you most want to recruit in.

- Aerospace Engineering
- Applied Mathematics
- Architectural Engineering
- Biological Sciences
- Business & Management Systems
- Ceramic Engineering
- Chemical Engineering
- Chemistry
- Civil Engineering
- Computer Engineering
- Computer Science
- Electrical Engineering
- Engineering Management
- Environmental Engineering
- Environmental Science
- Geological Engineering
- Geology
- History
- Information Science & Technology
- Mechanical Engineering
- Metallurgical Engineering
- Mining Engineering
- Nuclear Engineering
- Petroleum Engineering
- Physics
- Psychology
- Technical Communication
- Other *(enable the "Other" option)*

**Q4. Second major or minor** `[Text — optional]`
*Helper text:* We'll use this to widen your matches if it helps.

**Q5. Class standing this fall** `[Choice — required]`
- Freshman
- Sophomore
- Junior
- Senior
- Graduate student

**Q6. Expected graduation** `[Choice — required]`
- December 2026
- May 2027
- December 2027
- May 2028
- May 2029 or later

**Q7. What are you looking for?** `[Checkbox — required, select all that apply]`
- Summer internship
- Co-op (semester-long)
- Full-time job after graduation
- Just exploring / building my network

> ⚙️ **Note:** "Just exploring" is a real answer and won't hurt your matches — it tells the
> system to weight fit by major rather than by role type. Freshmen especially should feel
> free to pick it.

**Q8. Do you now or will you in the future require visa sponsorship to work in the US?** `[Choice — required]`
- No — I have permanent US work authorization
- Yes — I need or will need sponsorship

> ⚙️ **Why we ask:** This is a hard filter. We will never match you with a company that
> can't hire you, so you don't waste a conversation finding that out in person.

---

## SECTION 2 — What You Want *(this drives your matches)*

**Q9. Rank these industries from most to least interesting to you** `[Ranking — required]`
*Helper text:* Drag to reorder. Your top 3 matter most. Be honest rather than strategic — the system uses this to find you companies you'll actually want to talk to.

- Civil, Construction & Infrastructure
- Manufacturing & Industrial
- Mechanical, Aerospace & Defense
- Materials, Mining & Chemical
- Energy, Power & Utilities
- Electrical, Controls & Automation
- Software & IT
- Data, Systems & Analytics
- Business, Finance & Consulting

**Q10. Where do you want to work?** `[Choice — required]`
- Missouri specifically
- Midwest region
- Anywhere in the US

**Q11. What size company appeals to you?** `[Choice — required]`
- Small (under 100 people) — more responsibility early
- Mid-size (100–1,000)
- Large (1,000+) — structured programs, big name
- No preference

> ⚙️ **Why we ask:** Many of our guests are smaller regional firms who don't attend the
> career fair. If you want that, we'll point you at them.

---

## SECTION 3 — Your Dream List ⭐

**Q12. Name up to 3 companies you'd most like to meet — any company at all** `[Text — optional]`
*Helper text:* Separate with commas. **These do NOT have to be companies attending.** We are still sending invitations, and we genuinely use this list to decide who to chase. If a company you name ends up coming, you get an automatic guaranteed meeting with them.

**Q13. Is there a company already on our confirmed list you especially want to meet?** `[Text — optional]`
*Helper text:* Leave blank if you haven't seen the list yet — we'll email you a short follow-up in early September to pick your must-meets. You're not missing out by skipping this.

---

## SECTION 4 — Logistics

**Q14. Are you a member of any of the following?** `[Checkbox — required]`
- Sigma Phi Epsilon
- *[your co-sponsoring organization]*
- Neither — I saw this through campus

*Helper text:* This event is open to all S&T students. We ask only for our event reporting.

**Q15. Dietary restrictions** `[Text — optional]`
*Helper text:* Dinner is catered from Pancheros. We'll make sure there's something for you.

**Q16. Do you consent to photos being taken at the event?** `[Choice — required]`
- Yes
- No — please don't photograph me

*Helper text:* We're required to submit event photos to our campus funding sponsor.

**Q17. Have you attended a professional event like this before?** `[Choice — optional]`
- No, this is my first
- Yes, once or twice
- Yes, several

*Helper text:* No wrong answer. If this is your first, we'll pair you with a brother who can walk you in.

---

## ⚙️ FORM 1 SETTINGS
- Close date: **September 8**
- Cap: set to **4× your confirmed recruiter count** (30 recruiters → 120 students), waitlist beyond
- Thank-you message: *"You're registered. Watch your email around Sept 2 — we'll send a 30-second follow-up to let you pick your must-meet companies, plus your personalized card the week of the event."*

---
---

# FORM 2 — MUST-MEET PICKS *(send Sept 2, close Sept 8)*

Extremely short on purpose. Send it to registered students only. Subject line:
**"30 seconds: pick the 2 companies you most want to meet."**

> **Form title:** Recruiter Night — Pick Your Must-Meets
> **Form description:**
> Our recruiter list is locked. Pick the **two companies you most want to meet** and we'll
> guarantee you a seat with them, regardless of what the matching algorithm says.
> Everything else on your card gets matched to your major and interests automatically.
> This takes 30 seconds. If you skip it, we'll pick good ones for you based on what
> you told us when you registered — you won't lose anything.

**Q1. Your Missouri S&T email** `[Text — required, email format]`
*Helper text:* Must match the one you registered with so we can link your responses.

**Q2. Pick up to 2 companies you most want to meet** `[Checkbox — required, limit selection to 2]`
*Helper text:* Listed by industry. Full details on each company are in the email.

> Paste your confirmed roster here, grouped by industry, formatted as:
> `Company Name — Industry — hiring: Majors — roles: Internship/Co-op/Full-Time`
>
> Example:
> - Rolla Precision Machining — Manufacturing — hiring: Mechanical, Metallurgical, Engineering Management — roles: Internship, Co-op
> - Steelbridge Software — Software & IT — hiring: Computer Science, Computer Engineering, IST — roles: Internship, Full-Time

**Q3. Anything change since you registered?** `[Choice — optional]`
- Nope, all the same
- Yes — my class year or major changed *(add a follow-up text box via branching)*

## ⚙️ FORM 2 SETTINGS
- In Forms, use **Settings → limit selection** on Q2 to enforce exactly 2
- Send via email to registered students only, with a reminder 48 hours later
- Expect **50–70% response.** That's fine and fully planned for — non-responders get proxy wildcards automatically.

---
---

# 📋 RUNNING THE MATCH

1. Export all three forms: Responses → **Open in Excel**
2. Save as `recruiters_raw.xlsx`, `students_stage1.xlsx`, `students_stage2.xlsx`
3. Convert and run:

```bash
# Mid-August — see who students want you to invite
python forms_to_csv.py --recruiters recruiters_raw.xlsx \
                       --stage1 students_stage1.xlsx --dreamlist

# Sept 8 — build the match inputs
python forms_to_csv.py --recruiters recruiters_raw.xlsx \
                       --stage1 students_stage1.xlsx \
                       --stage2 students_stage2.xlsx \
                       --out-recruiters recruiters.csv \
                       --out-students students.csv

# Run the matcher
python matching_algorithm.py --recruiters recruiters.csv \
                      --students students.csv \
                      --matches 4 --wildcards 2 --equity 2 --excel
```

The converter reports which majors it couldn't recognize, how many wildcards came from
each layer, and flags any recruiter whose eligible student pool is too thin to fill.
