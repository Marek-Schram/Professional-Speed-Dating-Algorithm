# RECRUITER INTAKE FORM
### SigEp Mo Gamma — Recruiter Night · Missouri S&T
**Copy each block below into Microsoft Forms.** Question types are marked in `[brackets]`.
Send the link in your outreach email. Close it **Sept 1**.

> **Form title:** Recruiter Night at Missouri S&T — Employer Registration
> **Form description:**
> Thank you for joining us Tuesday, September 15 — one week before the S&T Career Fair.
> This is a free, seated, dinner-format event. We match you in advance with students who
> fit what you're hiring for, so you're not fielding 200 unfiltered résumés.
> This form takes about 4 minutes. Everything here feeds the matching system, so
> please be specific — the more precise your answers, the better your table traffic.

---

## SECTION 1 — Contact & Logistics

**Q1. Company / organization name** `[Text — required]`
*Helper text:* Exactly as you'd like it printed on your table tent and signage.

**Q2. Primary contact name** `[Text — required]`

**Q3. Primary contact email** `[Text — required, restrict to email format]`

**Q4. Mobile number for day-of coordination** `[Text — optional]`

**Q5. How many recruiters will attend from your company?** `[Choice — required]`
- 1
- 2
- 3
- 4 or more

> ⚙️ **Why this matters:** This is the single most important logistics question. The
> matching system weights your student load by rep count — two reps means you meet
> roughly twice as many students. Getting this wrong is the #1 cause of a lopsided room.

**Q6. Will you also be attending the S&T Career Fair on Tuesday, Sept 22?** `[Choice — required]`
- Yes, we're registered for the career fair
- No, we're not attending the career fair this year
- Undecided

*Helper text:* No wrong answer — this just helps us plan parking and setup.

---

## SECTION 2 — What You're Hiring For

**Q7. What roles are you recruiting for?** `[Checkbox — required, select all that apply]`
- Summer internship
- Co-op (semester-long)
- Full-time (May 2027 graduates)
- Full-time (December 2026 graduates)
- Rotational / leadership development program

**Q8. Do you have full-time openings, or internships and co-ops only?** `[Choice — required]`
- We have full-time openings for graduating seniors
- Internships and co-ops only right now
- Depends on the discipline — we'll discuss at the event

> ⚙️ **Why this matters:** In simulation, seniors seeking full-time-only roles were the
> group most likely to end up with a weak card, because only ~70% of firms had full-time
> openings. This question lets the system steer graduating seniors toward you if you're hiring.

**Q9. Which majors are you most interested in?** `[Checkbox — required, select all that apply]`
*Helper text:* Select generously. Selecting adjacent majors meaningfully increases your table traffic, and S&T students cross disciplines more than you'd expect.

- Aerospace Engineering
- Applied Mathematics
- Architectural Engineering
- Biological Sciences
- Business & Management Systems
- Ceramic Engineering
- Chemical Engineering
- Chemistry
- Civil Engineering
- Computer Engineering
- Computer Science
- Electrical Engineering
- Engineering Management
- Environmental Engineering
- Environmental Science
- Geological Engineering
- Geology
- History
- Information Science & Technology
- Mechanical Engineering
- Metallurgical Engineering
- Mining Engineering
- Nuclear Engineering
- Petroleum Engineering
- Physics
- Psychology
- Technical Communication
- Open to any major

**Q10. Which class years are you open to meeting?** `[Checkbox — required, select all that apply]`
- Freshman
- Sophomore
- Junior
- Senior
- Graduate student

**Q11. If we have strong sophomores in your target majors, would you be willing to meet a few?** `[Choice — required]`
- Yes — happy to meet promising underclassmen
- Only if they're exceptional
- No, we only recruit juniors and seniors

> ⚙️ **Why this matters — the single highest-leverage question on this form.**
> Missouri S&T has more underclassmen than upperclassmen, but most employers default to
> "junior/senior." In simulation, that left **15% of underclassmen with zero good matches.**
> When ~60% of firms answered "yes" here, that dropped to under 1% *and* overall match
> quality went **up**, because the room had more usable capacity. Sophomores are also
> your cheapest pipeline — they'll intern twice before they graduate.

**Q12. Which industry best describes your work?** `[Choice — required]`
*Helper text:* This sets your table color and where you sit in the room. Tables are grouped so related industries sit near each other.
- Civil, Construction & Infrastructure
- Manufacturing & Industrial
- Mechanical, Aerospace & Defense
- Materials, Mining & Chemical
- Energy, Power & Utilities
- Electrical, Controls & Automation
- Software & IT
- Data, Systems & Analytics
- Business, Finance & Consulting

**Q13. Can you sponsor work visas (CPT / OPT / H-1B) for any of your openings?** `[Choice — required]`
- Yes, for at least some roles
- No, all roles require permanent US work authorization
- Case-by-case / not sure yet

> ⚙️ **Why this matters:** This is a hard filter, not a preference. Roughly 18% of S&T
> students need sponsorship, and nothing wastes a conversation faster than discovering
> at minute six that a student isn't eligible. "Case-by-case" is treated as yes.

**Q14. Primary work locations for these roles** `[Text — required]`
*Helper text:* City, State. List up to three, comma-separated. Example: St. Louis, MO; Kansas City, MO

---

## SECTION 3 — Event Experience *(optional but appreciated)*

**Q15. Would you be willing to bring one real, non-confidential problem your team has faced?** `[Choice — optional]`
- Yes — I'll bring something students can dig into
- Maybe, tell me more
- I'd rather just talk with students

*Helper text:* Optional format we're piloting: a design that failed, a process that broke, a scheduling disaster. Students work it with you for a few minutes. It shows you how someone thinks — which is what you're actually screening for.

**Q16. Any dietary restrictions for your team?** `[Text — optional]`
*Helper text:* Dinner is catered. We'll accommodate.

**Q17. Would you like a reserved parking spot near the venue?** `[Choice — optional]`
- Yes please
- Not needed

*Helper text:* Career fair parking is famously limited. Ours isn't.

**Q18. Upload your company logo for table signage** `[File upload — optional, 1 file, 10 MB]`

**Q19. Anything else we should know?** `[Long text — optional]`

---

## ⚙️ CONFIGURATION NOTES

**Settings to enable in Microsoft Forms:**
- ✅ Anyone can respond (external recruiters have no S&T login)
- ✅ Record email address → **off** (you're collecting it in Q3 anyway; the built-in field only works for org accounts)
- ✅ Send receipt to respondents
- ✅ Customize thank-you message: *"You're confirmed. We'll send your matched student roster and table assignment the week of Sept 8."*

**Close date:** September 1 — you need a locked roster to run the match and print materials.

**Export:** Responses → Open in Excel. Checkbox answers export **semicolon-separated**, which is exactly the format the matching engine expects.
