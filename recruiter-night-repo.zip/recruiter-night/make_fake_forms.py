"""Generate realistic messy Microsoft Forms exports to test the converter."""
import random, pandas as pd, numpy as np
import mst_data as D

rng = random.Random(7)
IND = ["Civil, Construction & Infrastructure","Manufacturing & Industrial",
"Mechanical, Aerospace & Defense","Materials, Mining & Chemical",
"Energy, Power & Utilities","Electrical, Controls & Automation",
"Software & IT","Data, Systems & Analytics","Business, Finance & Consulting"]

MAJ = ["Aerospace Engineering","Applied Mathematics","Architectural Engineering",
"Biological Sciences","Business & Management Systems","Ceramic Engineering",
"Chemical Engineering","Chemistry","Civil Engineering","Computer Engineering",
"Computer Science","Electrical Engineering","Engineering Management",
"Environmental Engineering","Environmental Science","Geological Engineering",
"Geology","History","Information Science & Technology","Mechanical Engineering",
"Metallurgical Engineering","Mining Engineering","Nuclear Engineering",
"Petroleum Engineering","Physics","Psychology","Technical Communication"]

POOL = {b:[n for n,_ in v] for b,v in D.FIRMS_BY_BUCKET.items()}
BUCK = {"CIVIL":IND[0],"MFG":IND[1],"MECH":IND[2],"MATL":IND[3],"ENERGY":IND[4],
        "ELEC":IND[5],"SOFT":IND[6],"DATA":IND[7],"BIZ":IND[8]}
IMP = {"CIVIL":["Civil Engineering","Architectural Engineering","Environmental Engineering","Engineering Management"],
"MFG":["Mechanical Engineering","Engineering Management","Metallurgical Engineering","Electrical Engineering"],
"MECH":["Mechanical Engineering","Aerospace Engineering","Physics","Computer Engineering"],
"MATL":["Metallurgical Engineering","Ceramic Engineering","Chemical Engineering","Mining Engineering","Chemistry"],
"ENERGY":["Electrical Engineering","Nuclear Engineering","Mechanical Engineering","Chemical Engineering"],
"ELEC":["Electrical Engineering","Computer Engineering","Physics"],
"SOFT":["Computer Science","Computer Engineering","Information Science & Technology"],
"DATA":["Computer Science","Applied Mathematics","Information Science & Technology"],
"BIZ":["Engineering Management","Business & Management Systems","Applied Mathematics","Technical Communication"]}

# ---------- RECRUITER EXPORT ----------
rows=[]; used=set()
buckets = ["CIVIL"]*5+["MFG"]*5+["MECH"]*4+["ENERGY"]*4+["MATL"]*3+["SOFT"]*3+["DATA"]*3+["BIZ"]*2+["ELEC"]*1
for i,b in enumerate(buckets,1):
    names=[n for n in POOL[b] if n not in used]
    if not names: names=POOL[b]
    nm=rng.choice(names); used.add(nm)
    mj = rng.sample(IMP[b], k=min(len(IMP[b]), rng.choice([2,3,3,4])))
    if rng.random()<0.08: mj=["Open to any major"]
    roles=rng.choice([["Summer internship"],["Summer internship","Co-op (semester-long)"],
        ["Summer internship","Full-time (May 2027 graduates)"],
        ["Summer internship","Co-op (semester-long)","Full-time (May 2027 graduates)"]])
    ft=rng.choice(["We have full-time openings for graduating seniors",
        "Internships and co-ops only right now","Depends on the discipline — we'll discuss at the event"])
    gr=rng.choice([["Junior","Senior"],["Senior"],["Junior","Senior","Graduate student"],
        ["Sophomore","Junior","Senior"],["Freshman","Sophomore","Junior","Senior"]])
    soph=rng.choices(["Yes — happy to meet promising underclassmen","Only if they're exceptional",
        "No, we only recruit juniors and seniors"],weights=[60,25,15])[0]
    rows.append({
      "ID":i,"Start time":"9/1/2026","Completion time":"9/1/2026","Email":"","Name":"",
      "1. Company / organization name":nm,
      "2. Primary contact name":f"Contact {i}",
      "3. Primary contact email":f"recruiter{i}@example.com",
      "4. Mobile number for day-of coordination":"",
      "5. How many recruiters will attend from your company?":rng.choice(["1","1","1","2","2","3"]),
      "6. Will you also be attending the S&T Career Fair on Tuesday, Sept 22?":rng.choice(["Yes, we're registered for the career fair","No, we're not attending the career fair this year"]),
      "7. What roles are you recruiting for?":";".join(roles),
      "8. Do you have full-time openings, or internships and co-ops only?":ft,
      "9. Which majors are you most interested in?":";".join(mj),
      "10. Which class years are you open to meeting?":";".join(gr),
      "11. If we have strong sophomores in your target majors, would you be willing to meet a few?":soph,
      "12. Which industry best describes your work?":BUCK[b],
      "13. Can you sponsor work visas (CPT / OPT / H-1B) for any of your openings?":rng.choices(["Yes, for at least some roles","No, all roles require permanent US work authorization","Case-by-case / not sure yet"],weights=[30,55,15])[0],
      "14. Primary work locations for these roles":rng.choice(["St. Louis, MO","Kansas City, MO","Rolla, MO","Springfield, MO","Columbia, MO"]),
    })
pd.DataFrame(rows).to_excel("recruiters_raw.xlsx",index=False)

# ---------- STUDENT STAGE 1 ----------
FIRST=["Aaron","Blake","Caleb","Dylan","Ethan","Grant","Hunter","Isaac","Jacob","Kyle",
"Logan","Mason","Nathan","Owen","Parker","Ryan","Seth","Trevor","Wyatt","Austin","Cole",
"Derek","Evan","Garrett","Ian","Jared","Liam","Miles","Noah","Preston","Reid","Tanner"]
LAST=["Anderson","Barnes","Carter","Dunn","Ellis","Fischer","Hoffman","Jensen","Keller",
"Lawson","Mueller","Novak","Osborne","Reyes","Schmidt","Tucker","Vance","Walsh","Yates",
"Brennan","Callahan","Doyle","Farrell","Hendricks","Jacobs","Marsh","Nolan","Pruitt"]
# messy real-world major entries
MESSY={"Mechanical Engineering":["Mechanical Engineering","ME","mech e","Mechanical"],
"Computer Science":["Computer Science","CS","comp sci","Computer Sci"],
"Civil Engineering":["Civil Engineering","CE","Civil"],
"Electrical Engineering":["Electrical Engineering","EE","Electrical"],
"Chemical Engineering":["Chemical Engineering","ChemE","Chem E"],
"Aerospace Engineering":["Aerospace Engineering","AE","Aero"],
"Engineering Management":["Engineering Management","EM","Eng Mgmt"],
"Computer Engineering":["Computer Engineering","CpE","Comp E"],
"Information Science & Technology":["Information Science & Technology","IST","Info Science"]}
majors=list(D.MST_MAJOR_PCT); mw=np.array([D.MST_MAJOR_PCT[m] for m in majors]); mw/=mw.sum()
grades=list(D.GRADE_PCT); gw=np.array([D.GRADE_PCT[g] for g in grades]); gw/=gw.sum()
GMAP={"Freshman":"Freshman","Sophomore":"Sophomore","Junior":"Junior","Senior":"Senior","Grad Student":"Graduate student"}
allfirms=[r["1. Company / organization name"] for r in rows]
BIGNAMES=["Boeing","Burns & McDonnell","Caterpillar","Garmin","Ameren","Cerner","Emerson","Black & Veatch"]
nprng=np.random.default_rng(7)
srows=[]
for i in range(1,141):
    nm=f"{rng.choice(FIRST)} {rng.choice(LAST)}"
    maj=majors[nprng.choice(len(majors),p=mw)]
    disp=rng.choice(MESSY.get(maj,[maj]))
    gr=grades[nprng.choice(len(grades),p=gw)]
    if gr in("Freshman","Sophomore"): seek=rng.choice([["Summer internship"],["Summer internship","Co-op (semester-long)"],["Just exploring / building my network"]])
    elif gr=="Junior": seek=rng.choice([["Summer internship"],["Summer internship","Co-op (semester-long)"]])
    else: seek=rng.choice([["Full-time job after graduation"],["Summer internship","Full-time job after graduation"]])
    ranked=rng.sample(IND,len(IND))
    # dream list: mix of real attendees, big names not attending, blanks
    dl=[]
    if rng.random()<0.75:
        k=rng.choice([1,2,3])
        picks=[]
        if rng.random()<0.55: picks+=rng.sample(allfirms,k=min(k,2))
        picks+=rng.sample(BIGNAMES,k=1)
        dl=picks[:3]
    srows.append({
      "ID":i,"Start time":"8/10/2026","Completion time":"8/10/2026","Email":"","Name":"",
      "1. Full name":nm,"2. Missouri S&T email":f"{nm.split()[0].lower()}{i}@mst.edu",
      "3. Major":disp,"4. Second major or minor":"",
      "5. Class standing this fall":GMAP[gr],
      "6. Expected graduation":rng.choice(["December 2026","May 2027","May 2028","May 2029 or later"]),
      "7. What are you looking for?":";".join(seek),
      "8. Do you now or will you in the future require visa sponsorship to work in the US?":rng.choices(["No — I have permanent US work authorization","Yes — I need or will need sponsorship"],weights=[82,18])[0],
      "9. Rank these industries from most to least interesting to you":";".join(ranked),
      "10. Where do you want to work?":rng.choice(["Missouri specifically","Midwest region","Anywhere in the US"]),
      "11. What size company appeals to you?":rng.choice(["Small (under 100 people) — more responsibility early","Mid-size (100–1,000)","Large (1,000+) — structured programs, big name","No preference"]),
      "12. Name up to 3 companies you'd most like to meet — any company at all":", ".join(dl),
      "13. Is there a company already on our confirmed list you especially want to meet?":"",
      "14. Are you a member of any of the following?":rng.choice(["Sigma Phi Epsilon","Neither — I saw this through campus"]),
    })
pd.DataFrame(srows).to_excel("students_stage1.xlsx",index=False)

# ---------- STUDENT STAGE 2 (only ~62% respond) ----------
s2=[]
for r in srows:
    if rng.random()<0.62:
        s2.append({"ID":r["ID"],"Start time":"9/3/2026","Completion time":"9/3/2026","Email":"","Name":"",
          "1. Your Missouri S&T email":r["2. Missouri S&T email"],
          "2. Pick up to 2 companies you most want to meet":";".join(rng.sample(allfirms,2)),
          "3. Anything change since you registered?":"Nope, all the same"})
pd.DataFrame(s2).to_excel("students_stage2.xlsx",index=False)
print(f"recruiters={len(rows)}  students={len(srows)}  stage2_responses={len(s2)} ({100*len(s2)/len(srows):.0f}%)")
