"""Excel workbook writer for the Recruiter Night matcher (v2)."""

from __future__ import annotations

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

FONT = "Arial"
THIN = Side(style="thin", color="BFBFBF")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
HDR_FILL = PatternFill("solid", start_color="1F2A44")


def _hdr(ws, row, headers, widths=None):
    for c, h in enumerate(headers, 1):
        cell = ws.cell(row=row, column=c, value=h)
        cell.font = Font(name=FONT, bold=True, color="FFFFFF", size=10)
        cell.fill = HDR_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BOX
    if widths:
        for c, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(c)].width = w
    ws.freeze_panes = ws.cell(row=row + 1, column=1)


def _b(ws, r, c, val, bold=False, fill=None, color="000000", size=10, align="left"):
    cell = ws.cell(row=r, column=c, value=val)
    cell.font = Font(name=FONT, bold=bold, size=size, color=color)
    cell.alignment = Alignment(horizontal=align, vertical="center")
    cell.border = BOX
    if fill:
        cell.fill = PatternFill("solid", start_color=fill)
    return cell


def _fg(hexc):
    h = hexc.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return "000000" if (0.299 * r + 0.587 * g + 0.114 * b) > 150 else "FFFFFF"


def write_workbook(frames, m, cfg, path):
    a = frames["assignments"]
    load = frames["recruiter_load"]
    palette = frames["palette"]
    bg = frames["grade_equity"]
    wb = Workbook()

    # ---- Read Me --------------------------------------------------------
    ws = wb.active
    ws.title = "Read Me"
    ws.column_dimensions["A"].width = 112
    hunt = cfg.event_total_minutes - cfg.food_minutes - cfg.open_minutes
    lines = [
        ("Recruiter Night — Match Plan", True, 14),
        ("", False, 11),
        ("Sheets", True, 12),
        ("  Room Map          — table numbers in spectrum order; print A3, tape to the wall.", False, 11),
        ("  Color Key         — industry → colour + NUMBER + SHAPE. Never rely on colour alone:", False, 11),
        ("                      ~1 in 12 men has red-green colour deficiency.", False, 11),
        ("  Student Cards     — one printable block per student; cut and hand out at check-in.", False, 11),
        ("  Recruiter Rosters — hand each firm their sheet at the food table.", False, 11),
        ("  Recruiter Load    — live COUNTIF formulas; edit All Matches and this updates.", False, 11),
        ("  Grade Equity      — proof that underclassmen aren't being handed junk cards.", False, 11),
        ("  All Matches       — the raw assignment table.", False, 11),
        ("", False, 11),
        ("Run of show", True, 12),
        (f"  Doors + food, welcome and rules explained while everyone eats   {cfg.food_minutes} min", False, 11),
        (f"  Scavenger hunt: {cfg.matches_per_student} waves x "
         f"{hunt // cfg.matches_per_student} min                    {hunt} min", False, 11),
        (f"  Open mingling — no schedule, talk to whoever you want    {cfg.open_minutes} min", False, 11),
        ("", False, 11),
        ("Rules that make it work", True, 12),
        ("  1. Recruiters stay seated. Students rotate.", False, 11),
        ("  2. The RECRUITER initials the card — forces a name exchange at the close.", False, 11),
        ("  3. All stops initialled = raffle entry, drawn at the very end after open mingling.", False, 11),
        ("  4. Visit in the printed order — it is staggered so tables don't queue.", False, 11),
        ("  5. Table tents must show NUMBER + SHAPE + COLOUR, and be tall.", False, 11),
    ]
    for i, (t, bold, size) in enumerate(lines, 1):
        ws.cell(row=i, column=1, value=t).font = Font(name=FONT, bold=bold, size=size)

    # ---- Grade Equity ---------------------------------------------------
    ws = wb.create_sheet("Grade Equity")
    ws.cell(row=1, column=1,
            value="A 'strong' match = right or adjacent major AND a grade level the firm "
                  "actually wants.").font = Font(name=FONT, italic=True, size=10)
    _hdr(ws, 2, ["Grade", "Students", "Avg strong matches", "% with 2+ strong",
                 "% with ZERO strong", "Avg score"], [16, 11, 20, 18, 20, 12])
    for i, row in bg.reset_index(drop=True).iterrows():
        r = i + 3
        _b(ws, r, 1, row["Grade"], bold=True)
        _b(ws, r, 2, int(row["Students"]), align="center")
        _b(ws, r, 3, float(row["AvgStrong"]), align="center")
        _b(ws, r, 4, float(row["PctWith2Plus"]), align="center")
        c = _b(ws, r, 5, float(row["PctWith0"]), align="center")
        if row["PctWith0"] > 5:
            c.fill = PatternFill("solid", start_color="FFF2CC")
        _b(ws, r, 6, float(row["AvgScore"]), align="center")
    ws.cell(row=len(bg) + 4, column=1,
            value="Yellow = more than 5% of that class gets no strong match. Fix by "
                  "asking firms to open up to sophomores, not by changing the algorithm."
            ).font = Font(name=FONT, size=9, italic=True)

    # ---- Color Key ------------------------------------------------------
    ws = wb.create_sheet("Color Key")
    _hdr(ws, 1, ["Block", "Industry", "Code", "Colour", "Hex", "Shape", "Tables"],
         [8, 38, 9, 10, 10, 14, 30])
    for i, row in palette.iterrows():
        r = i + 2
        hexc = row["Hex"].lstrip("#")
        _b(ws, r, 1, int(row["Table Block"]), align="center")
        _b(ws, r, 2, row["Industry"], bold=True, fill=hexc, color=_fg(row["Hex"]))
        _b(ws, r, 3, row["Code"], align="center")
        _b(ws, r, 4, row["Color"], align="center")
        _b(ws, r, 5, row["Hex"], align="center")
        _b(ws, r, 6, row["Shape"], align="center")
        _b(ws, r, 7, row["Tables"])

    # ---- Room Map -------------------------------------------------------
    ws = wb.create_sheet("Room Map")
    ws.cell(row=1, column=1, value="ROOM LAYOUT — tables run in spectrum order, so "
                                   "neighbouring tables are neighbouring fields"
            ).font = Font(name=FONT, bold=True, size=12)
    ws.cell(row=2, column=1, value="Food along this wall — served FIRST, before the hunt"
            ).font = Font(name=FONT, italic=True, size=10)
    ordered = sorted(m.recruiters, key=lambda x: x.table)
    r = 4
    for start in range(0, len(ordered), 6):
        for c, rec in enumerate(ordered[start:start + 6], 1):
            hexc = rec.industry_obj.hex_color.lstrip("#")
            fg = _fg(rec.industry_obj.hex_color)
            _b(ws, r, c, f"TABLE {rec.table}", bold=True, fill=hexc, color=fg, align="center")
            _b(ws, r + 1, c, rec.company, fill=hexc, color=fg, size=9, align="center")
            _b(ws, r + 2, c, f"{rec.industry_obj.shape}  {rec.industry_obj.color_name}",
               fill=hexc, color=fg, size=9, align="center")
            ws.column_dimensions[get_column_letter(c)].width = 27
        ws.row_dimensions[r + 1].height = 28
        r += 4

    # ---- All Matches ----------------------------------------------------
    ws = wb.create_sheet("All Matches")
    cols = ["StudentID", "Student", "Major", "Grade", "Stop", "Table", "Company",
            "Industry", "Color", "Shape", "Score", "MajorFit", "Strong", "Source"]
    _hdr(ws, 1, cols, [11, 20, 30, 13, 7, 8, 34, 32, 10, 14, 8, 11, 9, 11])
    for i, row in a[cols].reset_index(drop=True).iterrows():
        for c, col in enumerate(cols, 1):
            v = row[col]
            _b(ws, i + 2, c, bool(v) if col == "Strong" else v,
               align="center" if col in ("Stop", "Table", "Score", "Strong") else "left")

    # ---- Recruiter Load (live formulas) ---------------------------------
    ws = wb.create_sheet("Recruiter Load")
    cols = ["Table", "Company", "Industry", "Reps", "Roles", "Grades", "Sponsors",
            "Target Majors", "Eligible Pool", "Students Assigned", "Per Rep", "Avg Score"]
    _hdr(ws, 1, cols, [7, 34, 32, 7, 24, 28, 10, 46, 13, 17, 10, 11])
    n = len(a) + 1
    for i, row in load.iterrows():
        r = i + 2
        _b(ws, r, 1, int(row["Table"]), align="center")
        _b(ws, r, 2, row["Company"], bold=True)
        _b(ws, r, 3, row["Industry"])
        _b(ws, r, 4, int(row["Reps"]), align="center")
        _b(ws, r, 5, row["Roles"])
        _b(ws, r, 6, row["Grades"])
        _b(ws, r, 7, row["Sponsors"], align="center")
        _b(ws, r, 8, row["TargetMajors"])
        _b(ws, r, 9, int(row["EligiblePool"]), align="center")
        _b(ws, r, 10, f"=COUNTIF('All Matches'!$G$2:$G${n},$B{r})", align="center")
        _b(ws, r, 11, f"=ROUND(J{r}/D{r},1)", align="center")
        _b(ws, r, 12, f"=ROUND(AVERAGEIF('All Matches'!$G$2:$G${n},$B{r},"
                      f"'All Matches'!$K$2:$K${n}),1)", align="center")
    s = len(load) + 2
    _b(ws, s, 2, "TOTAL / SPREAD", bold=True)
    _b(ws, s, 10, f"=SUM(J2:J{s-1})", bold=True, align="center")
    _b(ws, s, 11, f"=ROUND(STDEV(K2:K{s-1}),2)", bold=True, align="center")
    _b(ws, s, 12, f"=ROUND(AVERAGE(L2:L{s-1}),1)", bold=True, align="center")
    _b(ws, s + 1, 2, "Per Rep total = standard deviation (lower = more evenly spread)", size=9)

    # ---- Recruiter Rosters ----------------------------------------------
    ws = wb.create_sheet("Recruiter Rosters")
    for col, w in zip("ABCDEF", [7, 24, 32, 14, 22, 30]):
        ws.column_dimensions[col].width = w
    r = 1
    for rec in sorted(m.recruiters, key=lambda x: x.table):
        hexc = rec.industry_obj.hex_color.lstrip("#")
        fg = _fg(rec.industry_obj.hex_color)
        _b(ws, r, 1, f"T{rec.table}", bold=True, fill=hexc, color=fg, align="center")
        _b(ws, r, 2, rec.company, bold=True, fill=hexc, color=fg, size=12)
        _b(ws, r, 3, f"{rec.industry_obj.shape} {rec.industry_obj.color_name}",
           fill=hexc, color=fg)
        _b(ws, r, 4, f"{rec.reps} rep(s)", fill=hexc, color=fg, align="center")
        _b(ws, r, 5, ", ".join(rec.position_types), fill=hexc, color=fg)
        _b(ws, r, 6, rec.location, fill=hexc, color=fg)
        r += 1
        _b(ws, r, 1, "Wants:", size=9, bold=True)
        _b(ws, r, 2, ", ".join(rec.preferred_grades), size=9)
        _b(ws, r, 3, ", ".join(rec.target_majors[:4]), size=9)
        r += 1
        for h, c in zip(["Stop", "Student", "Major", "Grade", "Notes"], range(1, 6)):
            _b(ws, r, c, h, bold=True, fill="E8E8E8", align="center")
        r += 1
        for _, row in a[a["Company"] == rec.company].sort_values(["Stop", "Student"]).iterrows():
            _b(ws, r, 1, int(row["Stop"]), align="center")
            _b(ws, r, 2, row["Student"])
            _b(ws, r, 3, row["Major"])
            _b(ws, r, 4, row["Grade"])
            _b(ws, r, 5, "")
            r += 1
        r += 1

    # ---- Student Cards --------------------------------------------------
    ws = wb.create_sheet("Student Cards")
    for col, w in zip("ABCDEF", [7, 9, 34, 32, 13, 20]):
        ws.column_dimensions[col].width = w
    r = 1
    for sid, grp in a.groupby("StudentID"):
        stu = grp.iloc[0]
        _b(ws, r, 1, "Recruiter Night", bold=True, fill="1F2A44",
           color="FFFFFF", size=11)
        for c in range(2, 7):
            _b(ws, r, c, "", fill="1F2A44")
        _b(ws, r, 3, f"{stu['Student']}  •  {stu['Major']}  •  {stu['Grade']}",
           bold=True, fill="1F2A44", color="FFFFFF", size=11)
        r += 1
        for h, c in zip(["Stop", "Table", "Company", "Why you're matched",
                         "Colour / Shape", "Recruiter initials"], range(1, 7)):
            _b(ws, r, c, h, bold=True, fill="E8E8E8", size=9, align="center")
        r += 1
        for _, row in grp.sort_values("Stop").iterrows():
            hexc = row["Hex"].lstrip("#")
            fg = _fg(row["Hex"])
            _b(ws, r, 1, int(row["Stop"]), bold=True, align="center")
            _b(ws, r, 2, int(row["Table"]), bold=True, fill=hexc, color=fg, align="center")
            _b(ws, r, 3, row["Company"], bold=True)
            _b(ws, r, 4, row["WhyMatched"], size=9)
            _b(ws, r, 5, f"{row['Shape']} {row['Color']}", fill=hexc, color=fg,
               size=9, align="center")
            _b(ws, r, 6, "")
            r += 1
        _b(ws, r, 1, "All stops initialled = raffle entry. Drop at the door on your way out.",
           size=9)
        r += 2

    wb.save(path)
    return path
