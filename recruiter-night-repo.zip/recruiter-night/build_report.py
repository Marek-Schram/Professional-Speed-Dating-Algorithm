#!/usr/bin/env python3
"""Build the COER pitch report PDF."""

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (HRFlowable, KeepTogether, ListFlowable, ListItem,
                                PageBreak, Paragraph, SimpleDocTemplate, Spacer,
                                Table, TableStyle)

NAVY = colors.HexColor("#1F2A44")
ACCENT = colors.HexColor("#B01B2E")
GREY = colors.HexColor("#5A5A5A")
LIGHT = colors.HexColor("#F0F2F5")

ss = getSampleStyleSheet()

S = {
    "title": ParagraphStyle("title", parent=ss["Title"], fontName="Helvetica-Bold",
                            fontSize=21, leading=25, textColor=NAVY, spaceAfter=2),
    "sub": ParagraphStyle("sub", parent=ss["Normal"], fontName="Helvetica",
                          fontSize=11.5, leading=15, textColor=GREY,
                          alignment=TA_CENTER, spaceAfter=10),
    "h1": ParagraphStyle("h1", parent=ss["Heading1"], fontName="Helvetica-Bold",
                         fontSize=13.5, leading=17, textColor=NAVY,
                         spaceBefore=14, spaceAfter=6),
    "h2": ParagraphStyle("h2", parent=ss["Heading2"], fontName="Helvetica-Bold",
                         fontSize=11, leading=14, textColor=ACCENT,
                         spaceBefore=9, spaceAfter=4),
    "body": ParagraphStyle("body", parent=ss["Normal"], fontName="Helvetica",
                           fontSize=9.8, leading=13.6, spaceAfter=6,
                           alignment=TA_LEFT),
    "small": ParagraphStyle("small", parent=ss["Normal"], fontName="Helvetica",
                            fontSize=8.3, leading=11, textColor=GREY),
    "bullet": ParagraphStyle("bullet", parent=ss["Normal"], fontName="Helvetica",
                             fontSize=9.8, leading=13.4),
    "cell": ParagraphStyle("cell", parent=ss["Normal"], fontName="Helvetica",
                           fontSize=8.8, leading=11.6),
    "cellb": ParagraphStyle("cellb", parent=ss["Normal"], fontName="Helvetica-Bold",
                            fontSize=8.8, leading=11.6),
    "cellh": ParagraphStyle("cellh", parent=ss["Normal"], fontName="Helvetica-Bold",
                            fontSize=8.8, leading=11.6, textColor=colors.white),
    "pull": ParagraphStyle("pull", parent=ss["Normal"], fontName="Helvetica-Bold",
                           fontSize=10.2, leading=14, textColor=NAVY),
}


def P(t, s="body"):
    return Paragraph(t, S[s])


def bullets(items, style="bullet"):
    return ListFlowable(
        [ListItem(Paragraph(t, S[style]), leftIndent=12) for t in items],
        bulletType="bullet", start="•", leftIndent=14, bulletFontSize=8,
        spaceBefore=1, spaceAfter=5)


def rule(color=NAVY, w=1.1, before=2, after=7):
    return HRFlowable(width="100%", thickness=w, color=color,
                      spaceBefore=before, spaceAfter=after)


def table(data, widths, header=True, zebra=True, align=None):
    rows = []
    for i, row in enumerate(data):
        out = []
        for j, c in enumerate(row):
            if hasattr(c, "wrap"):
                out.append(c)
                continue
            if header and i == 0:
                st = S["cellh"]
            elif j == 0:
                st = S["cellb"]
            else:
                st = S["cell"]
            out.append(Paragraph(str(c), st))
        rows.append(out)
    t = Table(rows, colWidths=widths, repeatRows=1 if header else 0)
    cmds = [
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 4.5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4.5),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#C9CDD4")),
    ]
    if header:
        cmds += [("BACKGROUND", (0, 0), (-1, 0), NAVY)]
    if zebra:
        for r in range(1, len(data)):
            if r % 2 == 0:
                cmds.append(("BACKGROUND", (0, r), (-1, r), LIGHT))
    if align:
        for col, a in align.items():
            cmds.append(("ALIGN", (col, 0), (col, -1), a))
    t.setStyle(TableStyle(cmds))
    return t


def callout(title, body):
    inner = [Paragraph(f"<b>{title}</b>", S["pull"]), Spacer(1, 3),
             Paragraph(body, S["body"])]
    t = Table([[inner]], colWidths=[6.9 * inch])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
        ("LEFTPADDING", (0, 0), (-1, -1), 12),
        ("RIGHTPADDING", (0, 0), (-1, -1), 12),
        ("TOPPADDING", (0, 0), (-1, -1), 9),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 9),
        ("LINEBEFORE", (0, 0), (0, -1), 3, ACCENT),
    ]))
    return t


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(GREY)
    canvas.drawString(0.8 * inch, 0.55 * inch,
                      "SigEp Missouri Gamma  ·  Recruiter Night Proposal  ·  Prepared for Missouri S&T COER")
    canvas.drawRightString(7.7 * inch, 0.55 * inch, f"Page {doc.page}")
    canvas.setStrokeColor(colors.HexColor("#D5D8DD"))
    canvas.setLineWidth(0.5)
    canvas.line(0.8 * inch, 0.72 * inch, 7.7 * inch, 0.72 * inch)
    canvas.restoreState()


story = []
A = story.append

# ---------------------------------------------------------------- COVER BLOCK
A(P("Recruiter Night", "title"))
A(Paragraph("A pre–Career Fair matching event connecting Missouri S&amp;T students "
            "with employers who otherwise would not reach them", S["sub"]))
A(rule(ACCENT, 2.2, 0, 10))

hdr = table([
    ["Proposed by", "Sigma Phi Epsilon, Missouri Gamma Chapter — in partnership with a second registered student organization"],
    ["Proposed date", "Tuesday, September 15, 2026 — one week before the Fall Career Fair (Tue, Sept 22)"],
    ["Format", "Seated dinner + pre-matched conversation rounds. Business casual. Free to employers and students."],
    ["Scale", "~30 employers · ~120–140 students · open to the entire S&amp;T community"],
    ["The ask", "COER as named campus partner: guidance, endorsement, and coordination — no COER staffing or budget required"],
], [1.15 * inch, 5.75 * inch], header=False, zebra=True)
A(hdr)
A(Spacer(1, 12))

# ---------------------------------------------------------------- SUMMARY
A(P("Executive Summary", "h1"))
A(rule())
A(P("We are building a professional networking event that does something the Career Fair "
    "structurally cannot: <b>match students and recruiters to each other in advance</b>, so "
    "every conversation in the room is one both sides actually want to have."))
A(P("Each attendee — student and recruiter alike — completes a short intake form. A matching "
    "system we have already built and tested then produces a personalized card for every "
    "student listing four specific employers, with table numbers, colors, and the reason for "
    "each match. Recruiters receive the mirror image: a roster of exactly who is coming to "
    "their table and why."))
A(P("<b>This is designed to complement the Career Fair, not compete with it.</b> Our recruiting "
    "priority is small and mid-size regional firms who are not attending the fair, plus "
    "companies for whom a booth is not economical. For students, it functions as a low-stakes "
    "rehearsal one week before the real thing — particularly for freshmen and sophomores who "
    "are often intimidated by the fair floor."))
A(Spacer(1, 4))
A(callout("Why we are bringing this to COER first",
          "We are a student organization proposing to put employers in a room with S&amp;T students. "
          "We think that should happen with the career center's knowledge, guidance, and blessing — "
          "not around it. We would rather build this the way COER wants it built."))

# ---------------------------------------------------------------- PROBLEM
A(P("The Problem We Set Out to Solve", "h1"))
A(rule())
A(P("The Fall Career Fair hosts an average of 378 registered companies across a single five-hour "
    "window. It is an outstanding event, and it is the highest-stakes day on the S&amp;T calendar. "
    "But its scale creates three predictable gaps:"))
A(bullets([
    "<b>Cost excludes smaller employers.</b> Published 2025 booth packages ran $850 to $1,600, "
    "capped at four representatives. For a 12-person regional engineering firm, that is a "
    "meaningful line item to stand beside Caterpillar and Burns &amp; McDonnell.",
    "<b>Underclassmen are structurally squeezed.</b> Priority access has historically been given "
    "to juniors and above during the opening hour, and most employers default to recruiting "
    "juniors and seniors — while S&amp;T enrolls more underclassmen than upperclassmen.",
    "<b>Volume works against depth.</b> With hundreds of booths, students optimize for coverage "
    "and recruiters process volume. Neither side gets much signal.",
]))
A(P("Our event does not fix the Career Fair. It catches what falls through it."))

# ---------------------------------------------------------------- HOW IT WORKS
A(P("How the Event Works", "h1"))
A(rule())

A(P("1 · Both sides complete a short intake form", "h2"))
A(P("Recruiters tell us what roles they are hiring for, which majors they want, which class years "
    "they will meet, whether they can sponsor work visas, and how many representatives they are "
    "bringing. Students tell us their major, class year, what they are seeking, their industry "
    "preferences, and their visa status. Both forms take under five minutes."))

A(P("2 · A matching system pairs them before the event", "h2"))
A(P("Every possible student–employer pair is scored out of 100 on major fit (35 points), class "
    "year (25), role type (20), stated interest (15), and location (5). Partial credit applies to "
    "adjacent disciplines — a mechanical engineering student at an aerospace firm scores well, "
    "just not perfectly. <b>Work authorization is a hard filter, not a preference:</b> we will "
    "never seat a student with an employer who cannot hire them."))

A(P("3 · Every student gets a personalized card; every recruiter gets a roster", "h2"))
A(P("Students receive four matched employers with table numbers, industry colors, and a one-line "
    "explanation of why each match was made. Two of the four are the student's own picks. "
    "Recruiters receive the names, majors, and class years of everyone assigned to their table."))

A(P("4 · Dinner first, then structured rounds", "h2"))
A(P("The evening opens with 40 minutes of catered dinner with no structure at all — everyone eats "
    "together before anyone pitches anything. The matching rounds follow: four waves of "
    "approximately 24 minutes, with recruiters seated and students rotating. Visit orders are "
    "staggered so tables do not queue."))

A(Spacer(1, 6))
A(callout("The design principle",
          "Recruiters stay seated and students rotate. Nobody stands in a line. Nobody delivers "
          "the same elevator pitch forty times. The pre-matching means the average conversation "
          "starts at minute one instead of minute four."))

# ---------------------------------------------------------------- WHAT WE BUILT
A(P("What We Have Already Built and Tested", "h1"))
A(rule())
A(P("This is not a concept sketch. The full system is built, simulated, and validated against "
    "real Missouri S&amp;T population data."))

A(table([
    ["Component", "What it does", "Status"],
    ["Matching engine",
     "Assigns students to employers using constrained optimization. Guarantees a minimum load for "
     "every employer so smaller firms are never left sitting alone, and a minimum number of strong "
     "matches for every student.", "Built &amp; tested"],
    ["Employer intake form",
     "19 questions covering roles, target majors, class years, visa sponsorship, rep count, and "
     "logistics. Exports directly into the engine.", "Ready to deploy"],
    ["Student intake forms",
     "A registration form plus a 30-second follow-up once the employer roster is final, so students "
     "can register before recruiters have committed.", "Ready to deploy"],
    ["Data converter",
     "Turns raw form exports into match inputs. Handles abbreviations, misspellings, duplicate "
     "registrations, and missing responses without manual cleanup.", "Built &amp; tested"],
    ["Event day materials",
     "Auto-generates student cards, recruiter rosters, a color-coded room map, and table signage "
     "as a printable workbook.", "Built &amp; tested"],
    ["Employer demand report",
     "Ranks which companies students most want to meet — including firms not yet invited — to "
     "direct our outreach.", "Built &amp; tested"],
], [1.25 * inch, 4.5 * inch, 0.95 * inch],
    align={2: "CENTER"}))

A(Spacer(1, 10))
A(P("Simulation results", "h2"))
A(P("We modeled a 140-student, 30-employer event using Missouri S&amp;T's actual degree distribution "
    "and the industry mix of employers who typically recruit here. Results:"))

A(table([
    ["Class year", "Students", "Avg. strong matches", "% with 2 or more", "% with none"],
    ["Freshman", "34", "2.9", "100%", "0%"],
    ["Sophomore", "29", "3.1", "100%", "0%"],
    ["Junior", "37", "3.1", "100%", "0%"],
    ["Senior", "34", "3.1", "100%", "0%"],
    ["Graduate", "6", "2.8", "100%", "0%"],
], [1.35 * inch, 0.85 * inch, 1.6 * inch, 1.35 * inch, 1.05 * inch],
    align={1: "CENTER", 2: "CENTER", 3: "CENTER", 4: "CENTER"}))
A(Spacer(1, 4))
A(P("A “strong match” means the employer wants that major or an adjacent one <i>and</i> recruits "
    "that class year. Average conversation length: 8.8 minutes. Every student received four matches; "
    "no student was seated with an employer who could not hire them.", "small"))

# ---------------------------------------------------------------- FINDINGS
A(P("Two Findings That May Be Useful to COER", "h1"))
A(rule())
A(P("Building the simulation surfaced two structural patterns about S&amp;T recruiting that we did not "
    "expect, and that we suspect are useful well beyond our event."))

A(P("Finding 1 · The employer pool skews away from the largest student populations", "h2"))
A(P("We tallied 278 employers from the S&amp;T Handshake collection by industry and compared that mix "
    "against the university's degree distribution:"))
A(table([
    ["Industry", "Share of employers", "Share of student demand"],
    ["Civil / Construction / Infrastructure", "51.1%", "17.3%"],
    ["Manufacturing &amp; Industrial", "24.5%", "15.8%"],
    ["Mechanical / Aerospace / Defense", "3.2%", "14.1%"],
    ["Energy, Power &amp; Utilities", "4.3%", "13.1%"],
    ["Data, Systems &amp; Analytics", "1.4%", "8.6%"],
    ["Software &amp; IT", "1.8%", "8.4%"],
], [3.1 * inch, 1.9 * inch, 1.9 * inch], align={1: "CENTER", 2: "CENTER"}))
A(Spacer(1, 5))
A(P("Roughly half the employer market is civil and construction, while mechanical engineering "
    "(17.5% of degrees) and the computing disciplines (approximately 18% combined) are the largest "
    "student populations. We are deliberately over-recruiting mechanical, software, data, and "
    "energy firms to compensate, and capping civil and construction at five or six tables."))

A(P("Finding 2 · One question materially changes outcomes for underclassmen", "h2"))
A(P("When employers default to “juniors and seniors,” our simulation left roughly 15% of "
    "underclassmen with no strong match. We added a single question to the employer form — "
    "<i>“If we have strong sophomores in your target majors, would you be willing to meet a few?”</i> "
    "When about 60% of firms said yes, that figure fell below 1%, and <b>overall match quality "
    "improved</b>, because the room had more usable capacity."))
A(P("We are asking every employer that question, and we are happy to share what we learn."))

# ---------------------------------------------------------------- THE ASK
A(P("What We Are Asking For", "h1"))
A(rule())
A(P("We are not asking COER for funding, staffing, or space. We are asking for partnership, in "
    "four specific and low-effort forms:"))
A(bullets([
    "<b>Guidance on employer outreach etiquette.</b> We want to approach companies in a way that "
    "reflects well on the university and does not conflict with COER's employer relationships. If "
    "there are firms we should not contact, or language we should use, we want to know before we send.",
    "<b>Named campus partnership.</b> Listing COER as a partner lets us tell employers this event is "
    "coordinated with the career center rather than freelanced around it — which matters a great "
    "deal for credibility.",
    "<b>Calendar and messaging coordination</b> so our event reinforces Career Fair attendance rather "
    "than competing with it. We would like to actively promote the fair at our event.",
    "<b>A conversation about what would make this useful to you.</b> If COER has employers it has "
    "been trying to re-engage, or student populations it wants better served, we would rather build "
    "toward those goals than invent our own.",
]))

A(Spacer(1, 6))
A(callout("What COER gets from this",
          "A tested matching system and its underlying data, available to the university at no cost. "
          "Roughly 30 additional employer relationships cultivated on S&amp;T's behalf, with warm "
          "introductions passed along. A cohort of underclassmen who arrive at the Career Fair having "
          "already practiced. And a documented answer to whether pre-matching improves recruiting "
          "outcomes — a question worth knowing regardless of what happens to our event."))

A(Spacer(1, 8))
A(P("Timeline", "h2"))
A(table([
    ["Early August", "Meet with COER; incorporate guidance before any employer outreach begins"],
    ["August", "Employer invitations; student registration opens"],
    ["September 1", "Employer roster closes"],
    ["September 8", "Student registration closes; matching runs"],
    ["September 15", "Recruiter Night"],
    ["September 22", "Fall Career Fair — students arrive prepared"],
], [1.25 * inch, 5.65 * inch], header=False))

A(Spacer(1, 12))
A(rule(ACCENT, 1.6, 4, 6))
A(P("We would welcome the chance to walk through this in person, and we are genuinely open to "
    "reshaping it around what would be most useful to the career center. Nothing here is fixed "
    "except our interest in doing it well.", "body"))

A(Spacer(1, 8))
A(P("Sources: Missouri S&amp;T Career Opportunities and Employer Relations (career fair dates, employer "
    "packages); Missouri S&amp;T Handshake employer collection (industry mix, n=278); Data USA, Missouri "
    "University of Science and Technology (degree distribution, n=1,209). Simulation figures reflect "
    "modeled populations, not actual registrations.", "small"))

doc = SimpleDocTemplate(
    "/mnt/user-data/outputs/Recruiter_Night_COER_Proposal.pdf",
    pagesize=letter, leftMargin=0.8 * inch, rightMargin=0.8 * inch,
    topMargin=0.75 * inch, bottomMargin=0.85 * inch,
    title="Recruiter Night - Proposal for Missouri S&T COER",
    author="Sigma Phi Epsilon, Missouri Gamma Chapter")
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print("built")
