#!/usr/bin/env python3
"""
=============================================================================
 forms_to_csv.py — Microsoft Forms  ->  matching-engine CSVs
=============================================================================
 Converts the three Forms exports into the two CSVs `matching_algorithm.py` expects,
 and implements the THREE-LAYER WILDCARD system that lets students register
 before the recruiter roster is locked.

 WILDCARD PRIORITY
   Layer 3  Stage-2 confirmation pick      (student saw the real list)
   Layer 1  Dream-list name match          (named it before the list existed)
   Layer 2  Proxy from preference profile  (never picked anything)

 Nobody loses their wildcards for being unresponsive or early.

 USAGE
   # mid-August: which companies do students want you to invite?
   python forms_to_csv.py --stage1 students_stage1.xlsx --dreamlist

   # Sept 8: build match inputs
   python forms_to_csv.py --recruiters recruiters_raw.xlsx \
                          --stage1 students_stage1.xlsx \
                          --stage2 students_stage2.xlsx \
                          --out-recruiters recruiters.csv \
                          --out-students students.csv

 Robust to header drift: columns are found by keyword, not exact text.
 Requires pandas (+ openpyxl to read .xlsx).
=============================================================================
"""

from __future__ import annotations

import argparse
import difflib
import re
import sys
from collections import Counter, defaultdict
from typing import Dict, List, Optional, Sequence, Tuple

import pandas as pd

# =============================================================================
# CANONICAL VOCABULARIES  (must match matching_algorithm.py)
# =============================================================================

MAJORS = [
    "Aerospace Engineering", "Applied Mathematics", "Architectural Engineering",
    "Biological Sciences", "Business & Management Systems", "Ceramic Engineering",
    "Chemical Engineering", "Chemistry", "Civil Engineering",
    "Computer Engineering", "Computer Science", "Electrical Engineering",
    "Engineering Management", "Environmental Engineering", "Environmental Science",
    "Geological Engineering", "Geology", "History",
    "Information Science & Technology", "Mechanical Engineering",
    "Metallurgical Engineering", "Mining Engineering", "Nuclear Engineering",
    "Petroleum Engineering", "Physics", "Psychology", "Technical Communication",
    # present in S&T degree data / common write-ins
    "Elementary Education", "Materials Science & Engineering",
    "Systems Engineering", "Engineering Physics", "Economics",
]

# Common ways people write majors -> canonical name
MAJOR_ALIASES = {
    "me": "Mechanical Engineering", "mech e": "Mechanical Engineering",
    "meche": "Mechanical Engineering", "mechanical": "Mechanical Engineering",
    "cs": "Computer Science", "comp sci": "Computer Science",
    "compsci": "Computer Science", "computer sci": "Computer Science",
    "ce": "Civil Engineering", "civil": "Civil Engineering",
    "cpe": "Computer Engineering", "comp e": "Computer Engineering",
    "ee": "Electrical Engineering", "elec e": "Electrical Engineering",
    "electrical": "Electrical Engineering",
    "che": "Chemical Engineering", "chem e": "Chemical Engineering",
    "cheme": "Chemical Engineering", "chemical": "Chemical Engineering",
    "ae": "Aerospace Engineering", "aero": "Aerospace Engineering",
    "aerospace": "Aerospace Engineering",
    "em": "Engineering Management", "eng mgmt": "Engineering Management",
    "engineering mgmt": "Engineering Management",
    "ist": "Information Science & Technology",
    "info science": "Information Science & Technology",
    "information technology": "Information Science & Technology",
    "arch e": "Architectural Engineering", "arche": "Architectural Engineering",
    "architectural": "Architectural Engineering",
    "env e": "Environmental Engineering", "enve": "Environmental Engineering",
    "environmental": "Environmental Engineering",
    "met e": "Metallurgical Engineering", "mete": "Metallurgical Engineering",
    "metallurgy": "Metallurgical Engineering",
    "nuc e": "Nuclear Engineering", "nuke": "Nuclear Engineering",
    "nuclear": "Nuclear Engineering",
    "pet e": "Petroleum Engineering", "petroleum": "Petroleum Engineering",
    "mining": "Mining Engineering", "geo e": "Geological Engineering",
    "geological": "Geological Engineering",
    "bio": "Biological Sciences", "biology": "Biological Sciences",
    "biological science": "Biological Sciences",
    "math": "Applied Mathematics", "applied math": "Applied Mathematics",
    "mathematics": "Applied Mathematics",
    "bms": "Business & Management Systems", "business": "Business & Management Systems",
    "tech comm": "Technical Communication", "techcomm": "Technical Communication",
    "psych": "Psychology", "ceramic": "Ceramic Engineering",
    "matsci": "Materials Science & Engineering",
    "materials science": "Materials Science & Engineering",
    "materials": "Materials Science & Engineering",
}

INDUSTRIES = {
    "CIVIL": "Civil, Construction & Infrastructure",
    "MFG": "Manufacturing & Industrial",
    "MECH": "Mechanical, Aerospace & Defense",
    "MATL": "Materials, Mining & Chemical",
    "ENERGY": "Energy, Power & Utilities",
    "ELEC": "Electrical, Controls & Automation",
    "SOFT": "Software & IT",
    "DATA": "Data, Systems & Analytics",
    "BIZ": "Business, Finance & Consulting",
}
IND_BY_NAME = {v.lower(): k for k, v in INDUSTRIES.items()}

GRADES = ["Freshman", "Sophomore", "Junior", "Senior", "Grad Student"]

POSITION_MAP = [
    (("full-time", "full time", "fulltime"), "Full-Time"),
    (("co-op", "co op", "coop"), "Co-op"),
    (("intern",), "Internship"),
    (("rotational", "leadership development"), "Full-Time"),
]


# =============================================================================
# HELPERS
# =============================================================================


def norm(s) -> str:
    return re.sub(r"[^a-z0-9 &]", " ", str(s).lower()).strip()


def squash(s) -> str:
    return re.sub(r"[^a-z0-9]", "", str(s).lower())


def find_col(df: pd.DataFrame, *keywords: str, required: bool = True) -> Optional[str]:
    """Locate a column whose header contains ALL keywords (case-insensitive).
    Falls back to fuzzy match. Robust to Forms prepending numbering."""
    kws = [k.lower() for k in keywords]
    for c in df.columns:
        lc = str(c).lower()
        if all(k in lc for k in kws):
            return c
    joined = " ".join(kws)
    best = difflib.get_close_matches(joined, [str(c).lower() for c in df.columns],
                                     n=1, cutoff=0.55)
    if best:
        for c in df.columns:
            if str(c).lower() == best[0]:
                return c
    if required:
        print(f"  ⚠️  Could not find a column matching: {keywords}", file=sys.stderr)
    return None


def split_multi(v) -> List[str]:
    """Forms exports checkbox answers semicolon-separated; tolerate commas too."""
    if pd.isna(v):
        return []
    s = str(v)
    parts = s.split(";") if ";" in s else s.split(",")
    return [p.strip() for p in parts if p.strip()]


def canon_major(raw: str) -> Optional[str]:
    if not raw or pd.isna(raw):
        return None
    t = norm(raw)
    if not t:
        return None
    for m in MAJORS:
        if norm(m) == t:
            return m
    if t in MAJOR_ALIASES:
        return MAJOR_ALIASES[t]
    sq = squash(raw)
    for alias, m in MAJOR_ALIASES.items():
        if squash(alias) == sq:
            return m
    hit = difflib.get_close_matches(t, [norm(m) for m in MAJORS], n=1, cutoff=0.72)
    if hit:
        for m in MAJORS:
            if norm(m) == hit[0]:
                return m
    for m in MAJORS:                       # substring fallback
        if norm(m) in t or t in norm(m):
            return m
    return None


def canon_industry(raw: str) -> Optional[str]:
    if not raw or pd.isna(raw):
        return None
    t = norm(raw)
    for name, code in IND_BY_NAME.items():
        if norm(name) == t:
            return code
    hit = difflib.get_close_matches(t, [norm(n) for n in IND_BY_NAME], n=1, cutoff=0.6)
    if hit:
        for name, code in IND_BY_NAME.items():
            if norm(name) == hit[0]:
                return code
    for name, code in IND_BY_NAME.items():
        first = name.split(",")[0].split("&")[0].strip()
        if norm(first) and norm(first) in t:
            return code
    return None


def canon_positions(vals: Sequence[str]) -> List[str]:
    out = []
    for v in vals:
        lv = str(v).lower()
        for keys, canon in POSITION_MAP:
            if any(k in lv for k in keys) and canon not in out:
                out.append(canon)
    return out


def canon_grades(vals: Sequence[str]) -> List[str]:
    out = []
    for v in vals:
        lv = str(v).lower()
        if "fresh" in lv and "Freshman" not in out:
            out.append("Freshman")
        elif "soph" in lv and "Sophomore" not in out:
            out.append("Sophomore")
        elif "junior" in lv and "Junior" not in out:
            out.append("Junior")
        elif "senior" in lv and "Senior" not in out:
            out.append("Senior")
        elif ("grad" in lv or "master" in lv or "phd" in lv) and "Grad Student" not in out:
            out.append("Grad Student")
    return out


# Microsoft Forms prepends these metadata columns to every export. When a form
# allows anonymous responses, "Name" and "Email" come back EMPTY — and an empty
# column called "Name" will hijack any search for a name field. Drop them.
FORMS_META = {"id", "start time", "completion time", "email", "name",
              "last modified time", "total points", "quiz feedback"}


def read_any(path: str) -> pd.DataFrame:
    df = (pd.read_excel(path)
          if path.lower().endswith((".xlsx", ".xlsm", ".xls"))
          else pd.read_csv(path))
    drop = [c for c in df.columns
            if str(c).strip().lower() in FORMS_META
            and df[c].isna().all()]
    if drop:
        df = df.drop(columns=drop)
    return df


# =============================================================================
# RECRUITER CONVERSION
# =============================================================================


def convert_recruiters(path: str, verbose: bool = True) -> Tuple[pd.DataFrame, List[str]]:
    df = read_any(path)
    warn: List[str] = []

    c_company = find_col(df, "company")
    c_reps = find_col(df, "how many recruiters", required=False) or find_col(df, "reps", required=False)
    c_roles = find_col(df, "roles", "recruiting", required=False) or find_col(df, "roles", required=False)
    c_ft = find_col(df, "full-time openings", required=False) or find_col(df, "full time", required=False)
    c_majors = find_col(df, "majors")
    c_grades = find_col(df, "class years", required=False) or find_col(df, "class", required=False)
    c_soph = find_col(df, "sophomores", required=False)
    c_ind = find_col(df, "industry")
    c_visa = find_col(df, "sponsor", required=False)
    c_loc = find_col(df, "work locations", required=False) or find_col(df, "location", required=False)

    rows = []
    for i, r in df.iterrows():
        company = str(r[c_company]).strip()
        if not company or company.lower() == "nan":
            continue

        # reps
        reps = 1
        if c_reps is not None and not pd.isna(r[c_reps]):
            m = re.search(r"\d+", str(r[c_reps]))
            if m:
                reps = max(1, min(6, int(m.group())))

        # majors
        raw_majors = split_multi(r[c_majors]) if c_majors else []
        if any("any major" in str(x).lower() for x in raw_majors):
            majors = MAJORS[:]
        else:
            majors = []
            for x in raw_majors:
                cm = canon_major(x)
                if cm and cm not in majors:
                    majors.append(cm)
                elif not cm:
                    warn.append(f"{company}: unrecognised major '{x}'")
        if not majors:
            warn.append(f"{company}: NO recognisable target majors — defaulted to open")
            majors = MAJORS[:]

        # grades, with the sophomore override
        grades = canon_grades(split_multi(r[c_grades])) if c_grades else []
        if not grades:
            grades = ["Junior", "Senior"]
        if c_soph is not None and not pd.isna(r[c_soph]):
            sv = str(r[c_soph]).lower()
            if sv.startswith("yes") or "happy to meet" in sv:
                for g in ("Sophomore",):
                    if g not in grades:
                        grades.append(g)

        # positions
        pos = canon_positions(split_multi(r[c_roles])) if c_roles else []
        if c_ft is not None and not pd.isna(r[c_ft]):
            fv = str(r[c_ft]).lower()
            if "full-time openings" in fv or "we have full-time" in fv:
                if "Full-Time" not in pos:
                    pos.append("Full-Time")
            elif "only" in fv and "intern" in fv:
                pos = [p for p in pos if p != "Full-Time"] or ["Internship"]
        if not pos:
            pos = ["Internship"]

        ind = canon_industry(r[c_ind]) if c_ind else None
        if ind is None:
            ind = "MFG"
            warn.append(f"{company}: industry unclear — defaulted to Manufacturing")

        visa = "No"
        if c_visa is not None and not pd.isna(r[c_visa]):
            vv = str(r[c_visa]).lower()
            visa = "Yes" if (vv.startswith("yes") or "case" in vv or "not sure" in vv) else "No"

        loc = ""
        if c_loc is not None and not pd.isna(r[c_loc]):
            loc = str(r[c_loc]).split(";")[0].split(",")[0:2]
            loc = ", ".join([x.strip() for x in
                             str(r[c_loc]).replace(";", ",").split(",")[:2]])

        rows.append({
            "rid": f"R{len(rows)+1:03d}", "company": company, "industry": ind,
            "reps": reps, "target_majors": ";".join(majors),
            "position_types": ";".join(pos), "preferred_grades": ";".join(grades),
            "sponsors_visa": visa, "location": loc,
        })

    out = pd.DataFrame(rows)

    # ---- duplicate company handling --------------------------------------
    # Happens for real: a firm submits the form twice, or two offices of the
    # same company register separately. Two tables with identical names make
    # table tents and student cards ambiguous, so resolve it here.
    if len(out):
        emails = []
        c_email = find_col(df, "contact email", required=False) or find_col(df, "email", required=False)
        for i, r in df.iterrows():
            emails.append(str(r[c_email]).strip().lower() if c_email and not pd.isna(r[c_email]) else "")
        out["_email"] = emails[: len(out)]
        key = out["company"].map(lambda c: squash(c))
        dupes = key[key.duplicated(keep=False)]
        if len(dupes):
            for k in dupes.unique():
                idx = out.index[key == k].tolist()
                same_contact = len({out.loc[i, "_email"] for i in idx if out.loc[i, "_email"]}) == 1
                comp = out.loc[idx[0], "company"]
                if same_contact and len(idx) > 1:
                    # same person submitted twice -> merge into one table
                    keep, drop = idx[0], idx[1:]
                    out.loc[keep, "reps"] = int(out.loc[idx, "reps"].max())
                    for col in ("target_majors", "position_types", "preferred_grades"):
                        merged = []
                        for i in idx:
                            for v in str(out.loc[i, col]).split(";"):
                                if v and v not in merged:
                                    merged.append(v)
                        out.loc[keep, col] = ";".join(merged)
                    if (out.loc[idx, "sponsors_visa"] == "Yes").any():
                        out.loc[keep, "sponsors_visa"] = "Yes"
                    out = out.drop(index=drop)
                    warn.append(f"{comp}: duplicate submission from the same contact — "
                                f"MERGED into one table")
                else:
                    # genuinely different teams -> disambiguate by location
                    for n, i in enumerate(idx, 1):
                        loc = str(out.loc[i, "location"]).split(",")[0].strip()
                        out.loc[i, "company"] = (f"{comp} — {loc}" if loc
                                                 else f"{comp} ({n})")
                    warn.append(f"{comp}: {len(idx)} separate registrations — "
                                f"renamed by location so tables aren't ambiguous")
        out = out.drop(columns=["_email"]).reset_index(drop=True)
        out["rid"] = [f"R{i+1:03d}" for i in range(len(out))]

    return out, warn


# =============================================================================
# STUDENT CONVERSION  +  THREE-LAYER WILDCARDS
# =============================================================================


def match_company(name: str, roster: Dict[str, str]) -> Optional[str]:
    """Fuzzy-match a free-text company name to a confirmed recruiter rid."""
    if not name:
        return None
    t = squash(name)
    if not t or len(t) < 3:
        return None
    for comp, rid in roster.items():
        if squash(comp) == t:
            return rid
    for comp, rid in roster.items():
        sc = squash(comp)
        if t and (t in sc or sc in t) and min(len(t), len(sc)) >= 5:
            return rid
    hit = difflib.get_close_matches(norm(name), [norm(c) for c in roster], n=1, cutoff=0.82)
    if hit:
        for comp, rid in roster.items():
            if norm(comp) == hit[0]:
                return rid
    return None


def convert_students(stage1: str, recruiters: Optional[pd.DataFrame],
                     stage2: Optional[str] = None, n_wildcards: int = 2
                     ) -> Tuple[pd.DataFrame, List[str], Counter, Counter]:
    df = read_any(stage1)
    warn: List[str] = []

    c_name = find_col(df, "name")
    c_email = find_col(df, "email")
    c_major = find_col(df, "major")
    c_major2 = find_col(df, "second major", required=False)
    c_major_other = find_col(df, "selected other", required=False) or find_col(df, "other above", required=False)
    c_grade = find_col(df, "class standing", required=False) or find_col(df, "class", required=False)
    c_seek = find_col(df, "looking for", required=False)
    c_visa = find_col(df, "sponsorship", required=False)
    # Google Forms has no native ranking question, so the student form asks two
    # separate single-choice questions ("first choice" / "second choice" industry)
    # instead of one ranked list. Kept as two lookups rather than one.
    c_rank1 = find_col(df, "first choice", required=False)
    c_rank2 = find_col(df, "second choice", required=False)
    c_loc = find_col(df, "where do you want", required=False) or find_col(df, "work", "where", required=False)
    c_dream = find_col(df, "companies you", required=False) or find_col(df, "dream", required=False)
    c_conf = find_col(df, "confirmed list", required=False)

    roster: Dict[str, str] = {}
    rid_ind: Dict[str, str] = {}
    rid_grades: Dict[str, List[str]] = {}
    rid_pos: Dict[str, List[str]] = {}
    rid_visa: Dict[str, bool] = {}
    if recruiters is not None and len(recruiters):
        for _, r in recruiters.iterrows():
            roster[r["company"]] = r["rid"]
            rid_ind[r["rid"]] = r["industry"]
            rid_grades[r["rid"]] = str(r["preferred_grades"]).split(";")
            rid_pos[r["rid"]] = str(r["position_types"]).split(";")
            rid_visa[r["rid"]] = str(r["sponsors_visa"]).lower() == "yes"

    # ---- Stage 2 lookup: email -> [company names] ------------------------
    stage2_picks: Dict[str, List[str]] = {}
    if stage2:
        d2 = read_any(stage2)
        e2 = find_col(d2, "email")
        p2 = find_col(d2, "companies", required=False) or find_col(d2, "meet", required=False)
        if e2 and p2:
            for _, r in d2.iterrows():
                key = str(r[e2]).strip().lower()
                if key and key != "nan":
                    stage2_picks[key] = split_multi(r[p2])

    dream_counter: Counter = Counter()
    source_counter: Counter = Counter()
    rows = []

    for _, r in df.iterrows():
        name = str(r[c_name]).strip() if c_name else ""
        email = str(r[c_email]).strip().lower() if c_email else ""
        if not name or name.lower() == "nan":
            continue

        major = canon_major(r[c_major]) if c_major else None
        if major is None and c_major_other is not None and not pd.isna(r[c_major_other]) \
                and str(r[c_major_other]).strip():
            # dropdown said "Other" -- the real answer is in the follow-up text box
            major = canon_major(r[c_major_other]) or str(r[c_major_other]).strip()
        if major is None:
            alt = canon_major(r[c_major2]) if c_major2 else None
            if alt:
                major = alt
                warn.append(f"{name}: used second major (primary unrecognised)")
            else:
                # NEVER drop a registered student — they showed up to your form.
                # Keep the raw text; they'll still be matched via the equity and
                # floor phases, just without discipline-adjacency bonuses.
                major = str(r[c_major]).strip() if c_major else "Undeclared"
                warn.append(f"{name}: unrecognised major '{major}' — KEPT, "
                            f"add it to MAJORS for better matching")

        grade = "Junior"
        if c_grade is not None and not pd.isna(r[c_grade]):
            g = canon_grades([r[c_grade]])
            if g:
                grade = g[0]

        seeking = canon_positions(split_multi(r[c_seek])) if c_seek else []
        if not seeking:
            seeking = ["Internship"]          # "just exploring" -> widest net

        needs_visa = "No"
        if c_visa is not None and not pd.isna(r[c_visa]):
            needs_visa = "Yes" if str(r[c_visa]).lower().startswith("yes") else "No"

        # industries: first/second choice questions, in that priority order
        inds: List[str] = []
        for col in (c_rank1, c_rank2):
            if col is not None and not pd.isna(r[col]):
                ci = canon_industry(r[col])
                if ci and ci not in inds:
                    inds.append(ci)
        top_inds = inds[:2]

        loc_pref = "Anywhere"
        if c_loc is not None and not pd.isna(r[c_loc]):
            lv = str(r[c_loc]).lower()
            if "missouri" in lv:
                loc_pref = "Missouri"
            elif "midwest" in lv:
                loc_pref = "Midwest"

        # ---------------- WILDCARDS: three layers ------------------------
        wildcards: List[str] = []
        interest_companies: List[str] = []

        # Layer 3 — Stage-2 confirmation
        for cname in stage2_picks.get(email, []):
            rid = match_company(cname, roster)
            if rid and rid not in wildcards:
                wildcards.append(rid)
                interest_companies.append(cname)
        if wildcards:
            source_counter["stage2_confirmed"] += len(wildcards)

        # Layer 1 — dream list / stage-1 confirmed pick
        dream_raw: List[str] = []
        if c_dream is not None and not pd.isna(r[c_dream]):
            dream_raw += [x.strip() for x in re.split(r"[;,\n]", str(r[c_dream])) if x.strip()]
        if c_conf is not None and not pd.isna(r[c_conf]):
            dream_raw += [x.strip() for x in re.split(r"[;,\n]", str(r[c_conf])) if x.strip()]
        for d in dream_raw:
            dream_counter[d.strip().title()] += 1
        for d in dream_raw:
            if len(wildcards) >= n_wildcards:
                break
            rid = match_company(d, roster)
            if rid and rid not in wildcards:
                wildcards.append(rid)
                interest_companies.append(d)
                source_counter["dreamlist_matched"] += 1

        # Layer 2 — proxy from the preference profile
        if len(wildcards) < n_wildcards and roster:
            cands = []
            for comp, rid in roster.items():
                if needs_visa == "Yes" and not rid_visa.get(rid, False):
                    continue
                if rid in wildcards:
                    continue
                sc = 0.0
                ind = rid_ind.get(rid)
                if ind in inds:
                    sc += 40 - 6 * inds.index(ind)     # rank-weighted
                if grade in rid_grades.get(rid, []):
                    sc += 25
                if set(seeking) & set(rid_pos.get(rid, [])):
                    sc += 20
                cands.append((sc, comp, rid))
            cands.sort(key=lambda x: (-x[0], x[1]))
            for sc, comp, rid in cands:
                if len(wildcards) >= n_wildcards:
                    break
                if sc <= 0:
                    break
                wildcards.append(rid)
                source_counter["proxy_generated"] += 1

        rows.append({
            "sid": f"S{len(rows)+1:04d}", "name": name, "email": email,
            "major": major, "grade": grade, "seeking": ";".join(seeking),
            "interest_companies": ";".join(interest_companies),
            "interest_industries": ";".join(top_inds),
            "needs_sponsorship": needs_visa, "location_pref": loc_pref,
            "wildcards": ";".join(wildcards),
        })

    return pd.DataFrame(rows), warn, dream_counter, source_counter


# =============================================================================
# CLI
# =============================================================================


def main() -> None:
    p = argparse.ArgumentParser(description="Microsoft Forms -> matcher CSVs")
    p.add_argument("--recruiters", help="recruiter Forms export (.xlsx/.csv)")
    p.add_argument("--stage1", help="student registration export")
    p.add_argument("--stage2", help="student must-meet picks export")
    p.add_argument("--out-recruiters", default="recruiters.csv")
    p.add_argument("--out-students", default="students.csv")
    p.add_argument("--wildcards", type=int, default=2)
    p.add_argument("--dreamlist", action="store_true",
                   help="print the outreach target list and exit")
    args = p.parse_args()

    rec_df = None
    rwarn: List[str] = []
    if args.recruiters:
        print("Reading recruiter responses…")
        rec_df, rwarn = convert_recruiters(args.recruiters)
        print(f"  {len(rec_df)} recruiters, "
              f"{rec_df['reps'].sum() if len(rec_df) else 0} total reps")

    if not args.stage1:
        if rec_df is not None:
            rec_df.to_csv(args.out_recruiters, index=False)
            print(f"  wrote {args.out_recruiters}")
        return

    print("Reading student responses…")
    stu_df, swarn, dreams, sources = convert_students(
        args.stage1, rec_df, args.stage2, args.wildcards)
    print(f"  {len(stu_df)} students")

    # ---- dream-list outreach report -------------------------------------
    if args.dreamlist:
        print("\n" + "=" * 66)
        print(" OUTREACH TARGET LIST — companies your students asked for")
        print("=" * 66)
        roster = set(rec_df["company"]) if rec_df is not None else set()
        for comp, n in dreams.most_common(40):
            have = "✓ confirmed" if match_company(comp, {c: c for c in roster}) else "— NOT YET INVITED"
            print(f"  {n:>3} students   {comp[:44]:<44} {have}")
        print("\n  Chase the top uninvited names. This list is the highest-signal")
        print("  recruiting tool you have — students told you exactly who to email.\n")
        return

    # ---- write outputs ---------------------------------------------------
    if rec_df is not None:
        rec_df.to_csv(args.out_recruiters, index=False)
        print(f"  wrote {args.out_recruiters}")
    stu_df.drop(columns=["email"]).to_csv(args.out_students, index=False)
    print(f"  wrote {args.out_students}")

    # ---- diagnostics -----------------------------------------------------
    print("\n" + "=" * 66)
    print(" CONVERSION REPORT")
    print("=" * 66)
    print(" Wildcard sources:")
    tot = sum(sources.values()) or 1
    for k in ("stage2_confirmed", "dreamlist_matched", "proxy_generated"):
        v = sources.get(k, 0)
        print(f"   {k:<20} {v:>5}  ({100*v/tot:>4.1f}%)")
    nw = stu_df["wildcards"].apply(lambda s: len(str(s).split(";")) if s else 0)
    print(f"   students with 0 wildcards: {(nw == 0).sum()}")

    if rec_df is not None and len(rec_df):
        print("\n Capacity check:")
        reps = rec_df["reps"].sum()
        ratio = len(stu_df) / max(1, reps)
        print(f"   {len(stu_df)} students / {reps} reps = {ratio:.1f} students per rep")
        if ratio > 5.5:
            print("   ⚠️  Over 5.5 — cap registration or recruit more firms.")
        elif ratio < 2.5:
            print("   ⚠️  Under 2.5 — recruiters may be idle. Open more student seats.")
        else:
            print("   ✓ Healthy range.")

        soph = rec_df["preferred_grades"].str.contains("Sophomore").mean() * 100
        ft = rec_df["position_types"].str.contains("Full-Time").mean() * 100
        flag_s = "✓" if soph >= 60 else "⚠️ "
        flag_f = "✓" if ft >= 65 else "⚠️ "
        print(f"   {flag_s} firms open to sophomores:   {soph:>3.0f}%   (target 60%+)")
        print(f"   {flag_f} firms with full-time roles: {ft:>3.0f}%   (target 65%+)")
        if soph < 60:
            print("      → underclassmen will get weak cards. Email the firms that said")
            print("        'only if exceptional' and ask them to open up.")
        if ft < 65:
            print("      → graduating seniors have a thin market. Ask firms whether they")
            print("        have full-time openings, not just internships.")

    allw = rwarn + swarn
    if allw:
        print(f"\n Warnings ({len(allw)}):")
        for w in allw[:25]:
            print(f"   • {w}")
        if len(allw) > 25:
            print(f"   … and {len(allw)-25} more")
    else:
        print("\n ✓ No warnings — clean conversion.")

    print("\n Next:")
    print(f"   python matching_algorithm.py --recruiters {args.out_recruiters} "
          f"--students {args.out_students} --matches 4 --wildcards 2 --equity 2 --excel\n")


if __name__ == "__main__":
    main()
