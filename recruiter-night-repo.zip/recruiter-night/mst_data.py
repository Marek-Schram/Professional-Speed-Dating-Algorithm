"""
Real Missouri S&T population data for the Recruiter Night simulator.

SOURCES
  Majors    : Data USA, Missouri S&T degrees awarded (n = 1,209).
              https://datausa.io/profile/university/missouri-university-of-science-and-technology
  Employers : Missouri S&T Handshake employer collection (n = 278 firms),
              tallied by industry.
Both are ILLUSTRATIVE MODELS of the population, not a roster. Replace with
your real registration exports when they arrive.
"""

# =============================================================================
# 1. STUDENT MAJOR MIX  (% of degrees awarded, Data USA)
# =============================================================================
# Names normalised to the taxonomy the matcher uses.

MST_MAJOR_PCT = {
    "Mechanical Engineering": 17.50,
    "Computer Science": 9.76,          # "General Computer & Information Sciences"
    "Civil Engineering": 8.85,
    "Chemical Engineering": 8.02,
    "Electrical Engineering": 7.44,
    "Engineering Management": 6.45,    # "Engineering & Industrial Management"
    "Aerospace Engineering": 6.12,
    "Computer Engineering": 4.80,
    "Information Science & Technology": 3.64,
    "Business & Management Systems": 3.39,
    "Architectural Engineering": 3.14,
    "Biological Sciences": 3.06,
    "Environmental Engineering": 1.49,
    "Metallurgical Engineering": 1.49,
    "Nuclear Engineering": 1.49,
    "Psychology": 1.49,
    "Applied Mathematics": 1.41,
    "Chemistry": 1.32,
    "Physics": 1.24,
    "Ceramic Engineering": 1.24,
    "Mining Engineering": 1.16,
    "Petroleum Engineering": 0.91,
    "Technical Communication": 0.83,
    "History": 0.74,
    "Geological Engineering": 0.74,
    "Geology": 0.66,
    "Elementary Education": 0.58,
    "Environmental Science": 0.33,
}

# =============================================================================
# 2. EMPLOYER INDUSTRY MIX  (Handshake collection, n = 278)
# =============================================================================
# Raw Handshake labels -> the 9 room-colour buckets used by the matcher.

HANDSHAKE_COUNTS = {
    "Manufacturing": 53, "Construction": 51, "Civil Engineering": 46,
    "Engineering & Construction": 31, "Other Industries": 11,
    "Utilities and Renewable Energy": 10, "Government": 9,
    "Scientific and Technical Consulting": 6, "Food & Beverage": 5,
    "Natural Resources": 5, "Automotive": 4, "Defense": 4, "Oil & Gas": 4,
    "Aerospace": 3, "Electronic & Computer Hardware": 3,
    "Environmental Services": 3, "Information Technology": 3, "Research": 3,
    "Agriculture": 2, "Financial Services": 2, "Retail Stores": 2,
    "Energy": 2, "Medical Devices": 2, "Design": 2,
    "CPG - Consumer Packaged Goods": 2, "Architecture and Planning": 1,
    "Higher Education": 1, "Computer Networking": 1,
    "Legal & Law Enforcement": 1, "Accounting": 1,
    "Transportation & Logistics": 1, "Internet & Software": 1,
    "Real Estate": 1, "Investment Banking": 1,
    "Investment / Portfolio Management": 1,
}

HANDSHAKE_TO_BUCKET = {
    "Construction": "CIVIL", "Civil Engineering": "CIVIL",
    "Engineering & Construction": "CIVIL", "Architecture and Planning": "CIVIL",
    "Design": "CIVIL", "Transportation & Logistics": "CIVIL",
    "Real Estate": "CIVIL", "Government": "CIVIL",

    "Manufacturing": "MFG", "Automotive": "MFG", "Agriculture": "MFG",
    "Food & Beverage": "MFG", "CPG - Consumer Packaged Goods": "MFG",
    "Retail Stores": "MFG",

    "Aerospace": "MECH", "Defense": "MECH", "Medical Devices": "MECH",

    "Natural Resources": "MATL", "Oil & Gas": "MATL",
    "Environmental Services": "MATL", "Other Industries": "MATL",
    "Scientific and Technical Consulting": "MATL",

    "Utilities and Renewable Energy": "ENERGY", "Energy": "ENERGY",

    "Electronic & Computer Hardware": "ELEC",

    "Internet & Software": "SOFT", "Computer Networking": "SOFT",
    "Information Technology": "SOFT",

    "Research": "DATA", "Higher Education": "DATA",

    "Financial Services": "BIZ", "Accounting": "BIZ",
    "Investment Banking": "BIZ", "Investment / Portfolio Management": "BIZ",
    "Legal & Law Enforcement": "BIZ",
}


def bucket_mix():
    """Handshake industry counts collapsed into the 9 room buckets."""
    out = {}
    for label, n in HANDSHAKE_COUNTS.items():
        b = HANDSHAKE_TO_BUCKET[label]
        out[b] = out.get(b, 0) + n
    total = sum(out.values())
    return {k: v / total for k, v in sorted(out.items(), key=lambda x: -x[1])}


# =============================================================================
# 3. GRADE MIX
# =============================================================================
# Enrolment pyramid: more underclassmen than upperclassmen, and RSVP lists for
# a free-food networking night skew younger still (seniors are interviewing,
# freshmen are hungry and anxious).

GRADE_PCT = {
    "Freshman": 24.0,
    "Sophomore": 27.0,
    "Junior": 23.0,
    "Senior": 20.0,
    "Grad Student": 6.0,
}

# What employers actually ask for. Most want juniors/seniors; a minority are
# genuinely open to underclassmen (usually smaller/regional firms).
RECRUITER_GRADE_PROFILES = [
    (["Junior", "Senior"], 0.34),
    (["Senior"], 0.14),
    (["Junior", "Senior", "Grad Student"], 0.16),
    (["Sophomore", "Junior", "Senior"], 0.20),
    (["Sophomore", "Junior"], 0.06),
    (["Freshman", "Sophomore", "Junior", "Senior"], 0.10),
]

# =============================================================================
# 4. FIRM NAME POOL  (illustrative regional employers, by bucket)
# =============================================================================

FIRMS_BY_BUCKET = {
    "CIVIL": [
        ("Meramec Valley Constructors", "St. Louis, MO"),
        ("Gasconade Bridge & Steel", "Jefferson City, MO"),
        ("Ozark Site Development", "Springfield, MO"),
        ("Bluffline Civil Group", "Columbia, MO"),
        ("Heartland Structural Partners", "Kansas City, MO"),
        ("Cardinal Ridge Constructors", "St. Charles, MO"),
        ("Table Rock Infrastructure", "Branson, MO"),
        ("Big Piney Paving & Grading", "Rolla, MO"),
        ("Lafayette Square Builders", "St. Louis, MO"),
        ("Prairie State Transportation Group", "Springfield, IL"),
        ("Missouri River Geotechnical", "Jefferson City, MO"),
        ("Delmar Design Collective", "St. Louis, MO"),
    ],
    "MFG": [
        ("Rolla Precision Machining", "Rolla, MO"),
        ("Midstate Tooling & Die", "Sedalia, MO"),
        ("Cardinal Automation Works", "St. Charles, MO"),
        ("Prairie Fabrication Co.", "Wichita, KS"),
        ("Boonslick Conveyor Systems", "Boonville, MO"),
        ("Show-Me Plastics & Molding", "Joplin, MO"),
        ("Hermann Valve & Fitting", "Hermann, MO"),
        ("Cape Girardeau Bearing Works", "Cape Girardeau, MO"),
    ],
    "MECH": [
        ("Katy Trail Aerospace", "St. Louis, MO"),
        ("Lakeside Industrial Systems", "Lee's Summit, MO"),
        ("Vantage Thermal Solutions", "Tulsa, OK"),
        ("Whiteman Defense Technologies", "Knob Noster, MO"),
    ],
    "MATL": [
        ("Bonne Terre Materials Lab", "Bonne Terre, MO"),
        ("Ferric Alloys Midwest", "Granite City, IL"),
        ("Ozark Refractory Partners", "Joplin, MO"),
        ("Viburnum Trend Minerals", "Viburnum, MO"),
        ("St. Francois Environmental", "Farmington, MO"),
    ],
    "ENERGY": [
        ("Missouri Rural Electric Co-op", "Jefferson City, MO"),
        ("Confluence Power Services", "Alton, IL"),
        ("Windward Grid Consulting", "Kansas City, MO"),
        ("Ridgeline Renewables", "Des Moines, IA"),
    ],
    "ELEC": [
        ("Northline Controls & Instrumentation", "St. Louis, MO"),
        ("Frontier Switchgear", "Springfield, MO"),
        ("Delta Signal Engineering", "Memphis, TN"),
    ],
    "SOFT": [
        ("Steelbridge Software", "St. Louis, MO"),
        ("Riverbend Digital", "Kansas City, MO"),
        ("Loess Hills Technologies", "Omaha, NE"),
    ],
    "DATA": [
        ("Quarry Analytics", "St. Louis, MO"),
        ("Ninth Street Data Group", "Columbia, MO"),
    ],
    "BIZ": [
        ("Anchor Ridge Consulting", "Chicago, IL"),
        ("Mark Twain Financial Partners", "St. Louis, MO"),
        ("Phelps County Advisory", "Rolla, MO"),
    ],
}
